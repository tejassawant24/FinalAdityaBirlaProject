export interface Igoal{
    id:number,
    type:string,
    src:string
}