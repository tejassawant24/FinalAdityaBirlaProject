import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adityabirla',
  templateUrl: './adityabirla.component.html',
  styleUrls: [/*'./adityabirla.component.css'*/]
})
export class AdityabirlaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
